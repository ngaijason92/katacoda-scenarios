# Skills Challenge Template

This is a simplified "Hello, world" example for a skills challenge. It uses the challenge format v0.7, and illustrates how to define:

- tasks
- verification tests
- hints

Please reference the [detailed challenge documentation here](https://www.katacoda.community/challenges.html).