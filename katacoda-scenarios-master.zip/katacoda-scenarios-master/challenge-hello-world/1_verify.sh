test -f /root/bananas.txt
