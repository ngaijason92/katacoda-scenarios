# SOLUTIONS

For each task, please provide instructions for the solution. This is NOT shared with the learner, but is for our internal reference, to help test the scenario.

## Task 1 Solution

- Poke the widget
- Change the value
- Paste in the code
- Run the thing
- [etc...]

## Task 2 Solution

- xxxxx
- xxxxx
- xxxxx

## Task 3 Solution

- xxxxx
- xxxxx
- xxxxx

## Task 4 Solution

- xxxxx
- xxxxx
- xxxxx

## Task 5 Solution

- xxxxx
- xxxxx
- xxxxx
